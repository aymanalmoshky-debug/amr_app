مشروع Flutter - تطبيق الألغاز (جاهز للبناء)
-----------------------------------------

محتويات المشروع:
- pubspec.yaml
- lib/main.dart
- assets/questions.json

كيفية البناء على جهازك:
1) ثبت Flutter SDK واتبع خطوات التهيئة (flutter doctor).
2) انسخ المجلد إلى جهازك.
3) افتح طرفية في مجلد المشروع وشغّل:
   flutter pub get
   flutter run
4) لإنشاء APK قابل للتثبيت:
   - افتح android/app/build.gradle وعدّل minSdkVersion إلى 21 إن لزم.
   - ثم:
     flutter build apk --release
   - ستجد الملف في:
     build/app/outputs/flutter-apk/app-release.apk

ملاحظات:
- لا أستطيع بناء ملف APK هنا لأن بيئة التشغيل لا تحتوي على Flutter SDK أو أدوات Android.
- اذا تريد أجهز APK لك عبر GitHub Actions أو أوجّهك خطوة بخطوة لبناءه على جهازك، أخبرني وسأعطيك ملف GitHub Actions جاهز.

تواصل معي لو تريد:
- إضافة 100 سؤال جاهز، أو
- تخصيص شعار، أو
- إعداد GitHub Actions لبناء APK أو إنشاء ملف signed APK تلقائياً.
