
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'تطبيق الألغاز',
      debugShowCheckedModeBanner: false,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('ar')],
      locale: const Locale('ar'),
      home: const Directionality(textDirection: TextDirection.rtl, child: HomePage()),
      theme: ThemeData(
        textTheme: GoogleFonts.cairoTextTheme(),
        scaffoldBackgroundColor: Colors.transparent,
        useMaterial3: false,
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int levels = 10;
  int totalQuestions = 100;
  int bestScore = 0;

  @override
  void initState() {
    super.initState();
    _loadBestScore();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  }

  Future<void> _loadBestScore() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      bestScore = prefs.getInt('bestScore') ?? 0;
    });
  }

  Future<void> _updateBestScore(int score) async {
    final prefs = await SharedPreferences.getInstance();
    final prev = prefs.getInt('bestScore') ?? 0;
    if (score > prev) {
      await prefs.setInt('bestScore', score);
      setState(() => bestScore = score);
    }
  }

  void _startGame() async {
    final result = await Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizPage()));
    if (result is int) {
      await _updateBestScore(result);
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF6C7BFB), Color(0xFFECA7FF)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 20),
              Text('تطبيق الألغاز', style: GoogleFonts.cairo(fontSize: 36, fontWeight: FontWeight.w700, color: Colors.white)),
              const SizedBox(height: 6),
              Text('اختر معلوماتك الثقافية', style: GoogleFonts.cairo(fontSize: 14, color: Colors.white70)),
              const SizedBox(height: 30),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _statCard('نقاط ومكافآت', '---', w),
                    const SizedBox(width: 12),
                    _statCard('100 سؤال', '100', w),
                    const SizedBox(width: 12),
                    _statCard('10 مستويات', '10', w),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              SizedBox(
                width: w * 0.7,
                child: ElevatedButton(
                  onPressed: _startGame,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    elevation: 8,
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                  ),
                  child: Text('ابدأ اللعب', style: GoogleFonts.cairo(color: Color(0xFF6C7BFB), fontSize: 20, fontWeight: FontWeight.bold)),
                ),
              ),
              const Spacer(),
              Column(
                children: [
                  Text('أهلاً بكم', style: GoogleFonts.cairo(color: Colors.white70)),
                  const SizedBox(height: 4),
                  Text('برمجة وتصميم عمرو الأديب', style: GoogleFonts.cairo(color: Colors.white70)),
                  const SizedBox(height: 6),
                  Text('774586089', style: GoogleFonts.cairo(fontWeight: FontWeight.bold, color: Color(0xFFFFD54F))),
                  const SizedBox(height: 18),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _statCard(String title, String value, double w) {
    return Expanded(
      child: Container(
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.95),
          borderRadius: BorderRadius.circular(14),
          boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 8, offset: Offset(0,4))],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(value, style: GoogleFonts.cairo(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87)),
            const SizedBox(height: 6),
            Text(title, style: GoogleFonts.cairo(fontSize: 12, color: Colors.black54)),
          ],
        ),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});
  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  List<dynamic> _questions = [];
  int _index = 0;
  int _score = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadQuestions();
  }

  Future<void> _loadQuestions() async {
    final data = await rootBundle.loadString('assets/questions.json');
    setState(() {
      _questions = json.decode(data);
      _loading = false;
    });
  }

  void _answer(int choiceIndex) {
    final q = _questions[_index];
    if (choiceIndex == q['answer_index']) {
      _score += 10;
    }
    if (_index < _questions.length - 1) {
      setState(() => _index++);
    } else {
      Navigator.pop(context, _score);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final q = _questions[_index];
    return Scaffold(
      appBar: AppBar(
        title: Text('السؤال ${_index + 1} من ${_questions.length}'),
        backgroundColor: const Color(0xFF6C7BFB),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          children: [
            Text(q['question'], style: GoogleFonts.cairo(fontSize: 22, fontWeight: FontWeight.w600)),
            const SizedBox(height: 22),
            ...List.generate(q['choices'].length, (i) {
              return Container(
                margin: const EdgeInsets.symmetric(vertical: 8),
                child: ElevatedButton(
                  onPressed: () => _answer(i),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black87,
                    elevation: 4,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Align(alignment: Alignment.centerRight, child: Text(q['choices'][i], style: GoogleFonts.cairo(fontSize: 16))),
                ),
              );
            })
          ],
        ),
      ),
    );
  }
}
